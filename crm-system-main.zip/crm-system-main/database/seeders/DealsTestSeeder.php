<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\Leads\Models\Lead;
use Modules\Deals\Models\Deal;
use Modules\Deals\Models\Action;

class DealsTestSeeder extends Seeder
{
    public function run(): void
    {
        Lead::factory()->count(10)->create();

        Deal::factory()->count(20)->create()->each(function ($deal) {
            Action::factory()->count(rand(2, 5))->create([
                'deal_id' => $deal->id,
            ]);
        });
    }
}
