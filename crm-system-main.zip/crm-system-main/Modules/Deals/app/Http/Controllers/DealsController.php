<?php

namespace Modules\Deals\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\Deals\Models\Deal;
use Modules\Deals\Repositories\Deals\DealsRepositoryInterface;
use Modules\Leads\Models\Lead;

class DealsController extends Controller
{
    protected $dealsRepository;

    public function __construct(DealsRepositoryInterface $dealsRepository)
    {
        $this->dealsRepository = $dealsRepository;
    }
    public function index(Request $request)
    {
        $deals = $this->dealsRepository->filterDeals($request);
        $leads = Lead::all();

        return view('deals::index', compact('deals', 'leads'));
    }

     public function show($id)
    {
        $deal = $this->dealsRepository->findWithRelations($id);
        return view('deals::show', compact('deal'));
    }

}
