<?php

namespace Modules\Deals\Repositories\Deals;

use Illuminate\Http\Request;
use Modules\Deals\Repositories\Base\BaseRepositoryInterface;

interface DealsRepositoryInterface extends BaseRepositoryInterface
{
    public function filterDeals(Request $request);
    public function findWithRelations(int $id);
}
