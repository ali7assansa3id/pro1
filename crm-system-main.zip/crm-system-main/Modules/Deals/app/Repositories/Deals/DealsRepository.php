<?php

namespace Modules\Deals\Repositories\Deals;

use Illuminate\Http\Request;
use Illuminate\Pipeline\Pipeline;
use Modules\Deals\Repositories\Base\BaseRepository;
use Modules\Deals\Models\Deal;
use Modules\Deals\Pipelines\{
    ApplyFilters,
    ApplyFiltersById,
    ApplyRelatedFilters,
    FilterByDateRange,
    FilterByIsSuccess
};

class DealsRepository extends BaseRepository implements DealsRepositoryInterface
{
    public function __construct(Deal $model)
    {
        parent::__construct($model);
    }

    /**
     * Apply all filters dynamically using Laravel Pipeline
     */
    public function filterDeals(Request $request)
    {
        $query = $this->model->with(['lead', 'actions']);

        $query = app(Pipeline::class)
            ->send($query)
            ->through([
                new ApplyFilters([
                    'title' => 'title',
                ]),

                new ApplyFiltersById([
                    'lead_id' => 'lead_id',
                ]),

                new ApplyRelatedFilters([
                    'action_type' => ['actions', 'type'],
                    'lead_name'   => ['lead', 'name'],
                ]),

                new FilterByDateRange(),

                new FilterByIsSuccess(),
            ])
            ->thenReturn();

        return $query->orderByDesc('id')->paginate(10);
    }

    public function findWithRelations(int $id)
    {
        return $this->model->with(['lead', 'actions'])->findOrFail($id);
    }
}
