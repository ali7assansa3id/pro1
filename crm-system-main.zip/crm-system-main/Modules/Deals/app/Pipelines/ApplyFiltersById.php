<?php

namespace Modules\Deals\Pipelines;

use Closure;
use Illuminate\Support\Facades\Log;

class ApplyFiltersById
{
    protected $filters;

    public function __construct(array $filters)
    {
        $this->filters = $filters;
    }

    public function handle($query, Closure $next)
    {
        $criteria = app('request')->all();
        foreach ($this->filters as $key => $column) {

            if (isset($criteria[$key])) {
                 $query->where($column, $criteria[$key]);
            }
        }

        return $next($query);
    }
}
