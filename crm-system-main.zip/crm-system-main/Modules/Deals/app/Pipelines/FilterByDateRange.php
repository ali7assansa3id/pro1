<?php

namespace Modules\Deals\Pipelines;

use Closure;

class FilterByDateRange
{
    public function handle($query, Closure $next)
    {
        $criteria = app('request')->all();
        if (isset($criteria['from_date'])) {
            $query->whereDate('created_at', '>=', $criteria['from_date']);
        }

        if (isset($criteria['to_date'])) {
            $query->whereDate('created_at', '<=', $criteria['to_date']);
        }
        // dd($query->toSql());
        return $next($query);
    }
}
