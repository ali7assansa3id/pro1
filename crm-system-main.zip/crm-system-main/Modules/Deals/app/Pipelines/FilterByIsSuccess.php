<?php

namespace Modules\Deals\Pipelines;

use Closure;

class FilterByIsSuccess
{
    public function handle($query, Closure $next)
    {
        $criteria = app('request')->all();
        if (isset($criteria['is_success'])) {
            $query->where('is_success', $criteria['is_success']);
        }

        return $next($query);
    }
}
