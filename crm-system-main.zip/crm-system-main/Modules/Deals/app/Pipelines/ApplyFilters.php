<?php

namespace Modules\Deals\Pipelines;

use Closure;

class ApplyFilters
{
    protected $filters;

    public function __construct(array $filters)
    {
        $this->filters = $filters;
    }

    public function handle($query, Closure $next)
    {
        $criteria = app('request')->all();
        foreach ($this->filters as $key => $column) {
            if (isset($criteria[$key])) {
                $query->where($column, 'like', '%' . $criteria[$key] . '%');
            }
        }

        return $next($query);
    }
}
