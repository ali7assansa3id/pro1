<?php

namespace Modules\Deals\Pipelines;

use Closure;

class ApplyRelatedFilters
{
    protected $relatedFilters;

    public function __construct(array $relatedFilters)
    {
        $this->relatedFilters = $relatedFilters;
    }

    public function handle($query, Closure $next)
    {
        $criteria = app('request')->all();
        foreach ($this->relatedFilters as $key => [$relation, $column]) {
            if (isset($criteria[$key])) {
                $query->whereHas($relation, function ($subQuery) use ($criteria, $key, $column) {
                    $subQuery->where($column, 'like', '%' . $criteria[$key] . '%');
                });
            }
        }
        // dd($query);
        return $next($query);
    }
}
