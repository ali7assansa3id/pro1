<?php

namespace Modules\Deals\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Deals\Database\factories\DealFactory;

class Deal extends Model
{
    use HasFactory;

    protected $fillable = [
        'lead_id',
        'title',
        'expected_budget_from',
        'expected_budget_to',
        'is_success',
    ];

    protected static function newFactory()
    {
        return DealFactory::new();
    }

    public function lead()
    {
        return $this->belongsTo(\Modules\Leads\Models\Lead::class);
    }

    public function actions()
    {
        return $this->hasMany(Action::class);
    }
}
