<?php

namespace Modules\Deals\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Deals\Database\factories\ActionFactory;

class Action extends Model
{
    use HasFactory;

    protected $fillable = [
        'deal_id',
        'type',
        'description',
    ];

    protected static function newFactory()
    {
        return ActionFactory::new();
    }

    public function deal()
    {
        return $this->belongsTo(Deal::class);
    }
}
