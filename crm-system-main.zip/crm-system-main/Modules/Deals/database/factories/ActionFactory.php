<?php

namespace Modules\Deals\Database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\Deals\Models\Action;
use Modules\Deals\Models\Deal;

class ActionFactory extends Factory
{
    protected $model = Action::class;

    public function definition()
    {
        return [
            'deal_id' => Deal::inRandomOrder()->first()->id ?? Deal::factory(),
            'type' => $this->faker->randomElement(['call', 'meeting', 'note']),
            'description' => $this->faker->sentence(10),
            'created_at' => $this->faker->dateTimeThisMonth(),
        ];
    }
}
