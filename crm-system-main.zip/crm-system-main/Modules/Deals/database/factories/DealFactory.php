<?php

namespace Modules\Deals\Database\factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Modules\Deals\Models\Deal;
use Modules\Leads\Models\Lead;

class DealFactory extends Factory
{
    protected $model = Deal::class;

    public function definition()
    {
        return [
            'lead_id' => Lead::inRandomOrder()->first()->id ?? Lead::factory(),
            'title' => $this->faker->sentence(3),
            'expected_budget_from' => $this->faker->numberBetween(1000, 5000),
            'expected_budget_to' => $this->faker->numberBetween(6000, 15000),
            'created_at' => $this->faker->dateTimeThisYear(),
        ];
    }
}
