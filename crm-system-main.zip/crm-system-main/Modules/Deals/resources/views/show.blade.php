@extends('deals::layouts.app')

@section('content')
<div class="container">
    <a href="{{ route('deals.index') }}" class="btn btn-secondary mb-3">&larr; Back</a>

    <div class="card p-3 mb-4">
        <h4>{{ $deal->title }}</h4>
        <p><strong>Lead:</strong> {{ $deal->lead->name }}</p>
        <p><strong>Expected Budget:</strong> {{ $deal->expected_budget_from }} - {{ $deal->expected_budget_to }}</p>
    </div>

    <h5>Actions</h5>

    @if($deal->actions->count() > 0)
        <ul class="list-group">
            @foreach($deal->actions as $action)
                <li class="list-group-item">
                    <strong>{{ ucfirst($action->type) }}</strong>
                    <span class="text-muted">({{ $action->date }})</span>
                    <br>
                    {{ $action->description }}
                </li>
            @endforeach
        </ul>
    @else
        <p class="text-muted">No actions recorded for this deal.</p>
    @endif
</div>
@endsection
