@extends('deals::layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Deals List</h2>

    <form method="GET" action="{{ route('deals.index') }}" class="mb-4">
        <div class="row g-2 align-items-end">
            <div class="col-md-3">
                <label>Lead</label>
                <select name="lead_id" class="form-control">
                    <option value="">-- All Leads --</option>
                    @foreach($leads as $lead)
                        <option value="{{ $lead->id }}" {{ request('lead_id') == $lead->id ? 'selected' : '' }}>
                            {{ $lead->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="col-md-2">
                <label>Budget From</label>
                <input type="number" name="from" value="{{ request('from') }}" class="form-control" placeholder="From">
            </div>

            <div class="col-md-2">
                <label>Budget To</label>
                <input type="number" name="to" value="{{ request('to') }}" class="form-control" placeholder="To">
            </div>

            <div class="col-md-3">
                <label>Action Type</label>
                <select name="action_type" class="form-control">
                    <option value="">-- All Types --</option>
                    <option value="call" {{ request('action_type') == 'call' ? 'selected' : '' }}>Call</option>
                    <option value="meeting" {{ request('action_type') == 'meeting' ? 'selected' : '' }}>Meeting</option>
                    <option value="note" {{ request('action_type') == 'note' ? 'selected' : '' }}>Note</option>
                </select>
            </div>

            <div class="col-md-2">
                <label>From Date</label>
                <input type="date" name="from_date" value="{{ request('from_date') }}" class="form-control">
            </div>

            <div class="col-md-2">
                <label>To Date</label>
                <input type="date" name="to_date" value="{{ request('to_date') }}" class="form-control">
            </div>

            

            <div class="col-md-2">
                <button class="btn btn-primary w-100">Filter</button>
            </div>
        </div>
    </form>

    {{-- <div class="mb-3">
        <a href="{{ route('deals.create') }}" class="btn btn-success">+ Add Deal</a>
    </div> --}}

    <table class="table table-bordered table-striped align-middle">
        <thead class="table-light">
            <tr>
                <th>Title</th>
                <th>Lead</th>
                <th>Expected Budget</th>
                <th>Actions Count</th>
                <th>Created At</th>
                <th>Success</th>
                <th>View</th>
            </tr>
        </thead>
        <tbody>
            @forelse($deals as $deal)
                <tr>
                    <td>{{ $deal->title }}</td>
                    <td>{{ $deal->lead->name ?? '—' }}</td>
                    <td>{{ $deal->expected_budget_from }} - {{ $deal->expected_budget_to }}</td>
                    <td>{{ $deal->actions->count() }}</td>
                    <td>{{ $deal->created_at->format('Y-m-d') }}</td>
                    <td>
                        @if($deal->is_success)
                            <span class="badge bg-success">Yes</span>
                        @else
                            <span class="badge bg-secondary">No</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('deals.show', $deal) }}" class="btn btn-sm btn-info">View</a>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center text-muted">No deals found</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <div class="mt-3">
        {{ $deals->links() }}
    </div>
</div>
@endsection
