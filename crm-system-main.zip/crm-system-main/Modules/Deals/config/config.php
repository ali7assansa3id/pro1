<?php

return [
    'name' => 'Deals',
];
