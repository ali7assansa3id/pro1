<?php

use Illuminate\Support\Facades\Route;
use Modules\Deals\Http\Controllers\DealsController;

Route::prefix('deals')->group(function () {
    Route::get('/', [DealsController::class, 'index'])->name('deals.index');
    Route::get('/{deal}', [DealsController::class, 'show'])->name('deals.show');
});
