<x-actions::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('actions.name') !!}</p>
</x-actions::layouts.master>
