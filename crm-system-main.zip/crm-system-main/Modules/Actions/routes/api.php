<?php

use Illuminate\Support\Facades\Route;
use Modules\Actions\Http\Controllers\ActionsController;

Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('actions', ActionsController::class)->names('actions');
});
