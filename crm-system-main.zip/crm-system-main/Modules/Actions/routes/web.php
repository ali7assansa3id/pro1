<?php

use Illuminate\Support\Facades\Route;
use Modules\Actions\Http\Controllers\ActionsController;

Route::middleware(['auth', 'verified'])->group(function () {
    Route::resource('actions', ActionsController::class)->names('actions');
});
