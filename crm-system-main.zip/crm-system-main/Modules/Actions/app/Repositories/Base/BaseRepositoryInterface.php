<?php

namespace Modules\Actions\Repositories\Base;

interface BaseRepositoryInterface
{
    public function all();
    public function paginate(int $perPage = 30);

    public function find(int $id);

    public function create(array $attributes);

    public function update(int $id, array $attributes): bool;

    public function delete(int $id): bool;
}
