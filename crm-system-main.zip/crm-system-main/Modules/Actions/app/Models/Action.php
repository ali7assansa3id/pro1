<?php

namespace Modules\Actions\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Modules\Actions\Database\Factories\ActionFactory;

class Action extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [];

    // protected static function newFactory(): ActionFactory
    // {
    //     // return ActionFactory::new();
    // }
}
