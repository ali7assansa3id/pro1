<?php

return [
    'name' => 'Actions',
];
