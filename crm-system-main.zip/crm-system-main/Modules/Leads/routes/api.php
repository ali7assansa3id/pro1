<?php

use Illuminate\Support\Facades\Route;
use Modules\Leads\Http\Controllers\LeadsController;

Route::prefix('leads')->group(function () {
    Route::get('/', [LeadsController::class, 'index'])->name('leads.index');
    Route::get('/create', [LeadsController::class, 'create'])->name('leads.create');
    Route::post('/', [LeadsController::class, 'store'])->name('leads.store');
});
