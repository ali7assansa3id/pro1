<?php

namespace Modules\Leads\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Modules\Deals\Models\Deal;
use Modules\Leads\database\factories\LeadFactory;

class Lead extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'phone', 'email'];

    public function deals()
    {
        return $this->hasMany(Deal::class);
    }

    protected static function newFactory()
    {
        return LeadFactory::new();
    }
}
