<?php

namespace Modules\Leads\Repositories\Base;

use Modules\Leads\Repositories\Base\BaseRepositoryInterface;
use Exception;
use Illuminate\Database\Eloquent\Model;

abstract class BaseRepository  implements BaseRepositoryInterface
{
    protected $model;

    public function __construct(Model $model)
    {
        $this->model = $model;
    }

    public function all()
    {
        return $this->model->all();
    }

    public function paginate(int $perPage = 10)
    {
        return $this->model->orderBy('id', 'DESC')->paginate($perPage);
    }

    public function find(int $id)
    {
        $model = $this->model->find($id);

        if (!$model) {
            throw new Exception('not found');
        }

        return $model;
    }
    public function create(array $attributes)
    {
        return $this->model->create($attributes);
    }

    public function update(int $id, array $attributes): bool
    {
        $model = $this->find($id);
        return $model->update($attributes);
    }

    public function delete(int $id): bool
    {
        $model = $this->find($id);
        return $model->delete();
    }
}
