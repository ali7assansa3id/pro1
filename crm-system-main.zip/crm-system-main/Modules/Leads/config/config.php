<?php

return [
    'name' => 'Leads',
];
