<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Actions\\Providers\\ActionsServiceProvider',
    1 => 'Modules\\Deals\\Providers\\DealsServiceProvider',
    2 => 'Modules\\Leads\\Providers\\LeadsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Actions\\Providers\\ActionsServiceProvider',
    1 => 'Modules\\Deals\\Providers\\DealsServiceProvider',
    2 => 'Modules\\Leads\\Providers\\LeadsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);